;(function(){
    function fixImageSrc(res){
        var imgs = document.getElementsByTagName('img');
        for(var i=0,len=imgs.length; i<len; i++){
            var img = imgs[i];
            var dataSrc = img.getAttribute('src-fix');
            var data = res[dataSrc];
            if(dataSrc && data){
                img.setAttribute('src', data.url);
            }
        }
    }

    var loader;
    function startLoading(){
        var domLoad = document.getElementById('evt_loading');
        loader = new Loader('images/');
        domLoad.style.display = 'block';
        loader.addGroup('preload', resData);
        loader.on('progress', function(groupName, ix, len){
            domLoad.innerHTML = parseInt(ix/len*100) + '%';
        })
        loader.on('complete', function(groupName){
            fixImageSrc(loader.getAll());
            domLoad.style.display = 'none';
            document.getElementById('evt_content').style.display = 'block';
            loadComplete();
            console.log(loader.getAll())
        });
        loader.loadGroup('preload');
    }

    var loadComplete = function () {
        animtion.heart();
    };


    var animtion = {
        heart:function () {
            //图片配置
            var mcConfig = [
                {"x":133,"y":1,"w":130,"h":81,"offX":0,"offY":10,"sourceW":130,"sourceH":99,"duration":2},
                {"x":265,"y":1,"w":130,"h":75,"offX":0,"offY":14,"sourceW":130,"sourceH":99,"duration":0},
                {"x":1,"y":1,"w":130,"h":99,"offX":0,"offY":0,"sourceW":130,"sourceH":99,"duration":4},
                {"x":1,"y":102,"w":130,"h":91,"offX":0,"offY":4,"sourceW":130,"sourceH":99,"duration":20}
            ];
            // MovieClip 可以通过duration控制两张图片轮播的速度。
            new MovieClip('heart', loader.get('heart_png').data, mcConfig).play();
        },
        arrow:function () {

        }
    };

    startLoading();

})();